### Referencias

* https://www.kaggle.com/justinas/nba-players-data


* https://towardsdatascience.com/exploratory-data-analysis-eda-python-87178e35b14


* https://www.kaggle.com/ekami66/detailed-exploratory-data-analysis-with-python


* https://seaborn.pydata.org/tutorial/distributions.html


* https://towardsdatascience.com/histograms-and-density-plots-in-python-f6bda88f5ac0


* https://seaborn.pydata.org/tutorial/color_palettes.html
