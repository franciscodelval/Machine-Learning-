### Dictionary


* **player_name**: Nombre del jugador


* **team_abbreviation**: Nombre abreviado del equipo en el que jugo el juagodr (al final de la temporada)


* **age**: Edad del jugador


* **player_height**: Altura del jugador en cm


* **player_weight**: Peso del jugador en kg


* **college**: Nombre de la universidad que asisitio el jugador


* **country**: Nombre del pais en el que nacio el jugador 


* **draft_year**: Año en que se seleccionó al jugador 


* **draft_round**: Ronda de draft que eligió al jugador


* **draf_number**: El número en el que se eligió al jugador en su ronda de draft


* **gp**: Juegos jugados durante la temporada


* **pts**: Número medio de puntos anotados


* **reb**: Número medio de rebotes capturados


* **ast**: Número medio de asistencias distribuidas


* **net_rating**:Diferencia de puntos del equipo por cada 100 posesiones mientras el jugador está en la cancha


* **oreb_pct**: Porcentaje de rebotes ofensivos disponibles que el jugador agarró mientras estaba en el piso


* **dreb_pct**:Porcentaje de rebotes defensivos disponibles que el jugador agarró mientras estaba en el piso


* **usg_pct**: Porcentaje de jugadas de equipo utilizadas por el jugador mientras estaba en la cancha


* **ts_pct**: Medida de la eficiencia de tiro del jugador que tiene en cuenta los tiros libres, tiros de 2 y 3 puntos 
